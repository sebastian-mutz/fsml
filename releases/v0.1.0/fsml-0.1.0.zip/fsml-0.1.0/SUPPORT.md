# Support

## Handbook

The [FSML Handbook](https://fsml.mutz.science/page/index.html) includes a short tutorial, detailed API documentation, and more. It's a good place to start looking for helpful information.

## Bug Report

If you want to report an issue (or make a suggestion), please open an issue and follow the instructions [here](CONTRIBUTING.md)

## Contact

For anything else, feel free to e-mail [sebastian@mutz.science](mailto:sebastian@mutz.science).

