---
title: Contributing
---
@note
The most helpful contributions - at the moment - is an engagement with
the library and reporting what works well, what doesn't work, and what needs to
be done to make it work for you.
Open an issue on [GitHub](https://github.com/sebastian-mutz/fsml) with your
comments and suggestions, or [e-mail me](mailto:sebastian@mutz.science) if you
think the GitHub issue format is not suitable for what you'd like to dicuss.
@endnote

{!CONTRIBUTING.md!}
