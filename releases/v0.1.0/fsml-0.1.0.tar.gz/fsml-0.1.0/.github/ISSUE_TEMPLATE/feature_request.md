---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**How does the feature fit the scope and aims of the project?**
A clear and concise description of how it fits.

**Describe the feature**
A clear and concise description of the feature. Provide examples of similar implementations elsewhere.
