---
title: Licence (MIT)
---

{!LICENCE!}
